
// Sayaç
let time = 599;
const timerElement = document.getElementById('timer');
const interval = setInterval(() => {
    let minutes = Math.floor(time / 60);
    let seconds = time % 60;
    timerElement.textContent = `${minutes.toString().padStart(2,'0')}:${seconds.toString().padStart(2,'0')}`;
    if(time <= 0) clearInterval(interval);
    time--;
}, 1000);

// Form submit
document.getElementById('paymentForm').addEventListener('submit', function(e) {
    e.preventDefault();
    document.getElementById('confirmationModal').style.display = 'flex';
    let qrcode = new QRCode(document.getElementById('qrcode'), {
        text: "https://www.yapikredi.com.tr/odeme-basarili",
        width: 128,
        height: 128
    });
});

function closeModal(){
    document.getElementById('confirmationModal').style.display = 'none';
}
